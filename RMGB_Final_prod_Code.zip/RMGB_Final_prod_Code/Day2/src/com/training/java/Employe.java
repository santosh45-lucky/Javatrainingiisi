package com.training.java;

import java.util.*;
public class Employe{
private int empid;
private String empname;
private double salary;
private double bouns;
Scanner sc=new Scanner(System.in);  
public void accpectDeatail(){
System.out.println("enter emp id");
empid=sc.nextInt();
System.out.println("enter emp name");
empname=sc.next();
System.out.println("enter emp salary");
salary=sc.nextDouble();
}
public double calculateBouns(){
if(salary>=30000&&salary<=50000){
 bouns=salary*0.1;

}
else{
 bouns=salary*0.2;
}
return bouns;
}
public void display(){
System.out.println("empname:"+empname);
System.out.println("bouns is:");
System.out.println(calculateBouns());
}
public static void main(String args[]){
Employe emp1=new Employe();
emp1.accpectDeatail();
emp1.display(); 
}




}