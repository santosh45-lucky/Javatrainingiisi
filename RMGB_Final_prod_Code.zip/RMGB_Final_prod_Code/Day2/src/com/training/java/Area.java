package com.training.java;

import java.util.Scanner;
public class Area{
private static  float length;
private static float breath;
private double area;
Scanner sc=new Scanner(System.in);
public void accpect(){
	System.out.println("enter length");
	length=sc.nextFloat();
	System.out.println("enter Breath");
	breath=sc.nextFloat();	
	} 
public void display(float l,float b){
area=l*b;
System.out.println("Arrea of an rectngle is:"+area);

}
public static void main(String args[]){
Area ob=new Area();
ob.accpect();
ob.display(length,breath);
Area ob2=new Area();
ob2.accpect();
ob2.display(length,breath);
}
}