package com.training.java;

import java.util.*;
public class SubArray{
	int num[]=new int[]{10,20,30,40,50,60,70,80,90};
	public void findsubarray(){
	for(int i=3;i<8;i++){
	System.out.println(num[i]);
	}
	}
public static void main(String args[]){
SubArray ob=new SubArray();
ob.findsubarray();
}
}
