package com.training.java;

import java.util.*;
public class Check{
int num[];
Scanner sc;
int check;
int totalnum;
Check(){
	sc=new Scanner(System.in);
	System.out.println("Enter total number");
	totalnum=sc.nextInt();
	num=new int[totalnum];
	}
public void accpect(){
System.out.println("enter number");
for(int i=0;i<totalnum;i++){
num[i]=sc.nextInt();
}
System.out.println("enter a number do you want to cehck");
check=sc.nextInt();
} 
public void find(){
for(int i=0;i<totalnum;i++){
if(check==num[i]){
System.out.println("it is present at the"+i+"pposition");

}else if(i==totalnum-1){
System.out.println("it is not present in the array");
}
}
}
public static void main(String args[]){
Check ob=new Check();
ob.accpect();
ob.find();
}
}
