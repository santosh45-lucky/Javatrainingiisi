package com.training.java;

import java.util.*;
public class Calculator{
private int num1;
private int num2;
private int sum;
private int mul;
private float div;
Scanner sc;
Calculator(){
	sc=new Scanner(System.in);
	System.out.println("Enter num1");
	num1=sc.nextInt();
	System.out.println("enter num2");
	num2=sc.nextInt();
	} 
	public void add()
	{
		sum=num1+num2;
		System.out.println("Sum is:"+sum);
	}
	public void mul()
	{
		mul=num1*num2;
		System.out.println("mul is:"+mul);
	}
	public void div()
	{
	div=num1/num2;
	System.out.println("div is:"+div);
	}
	public static void main(String args[]){
	Calculator ob=new Calculator();
	ob.add();
	ob.mul();
	ob.div();
	}	 
}

