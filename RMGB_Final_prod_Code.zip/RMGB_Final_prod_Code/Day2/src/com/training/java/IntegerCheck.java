package com.training.java;

import java.util.*;
public class IntegerCheck{
int num[];
Scanner sc;
int totalnum;
IntegerCheck(){
	sc=new Scanner(System.in);
	System.out.println("Enter total number");
	totalnum=sc.nextInt();
	num=new int[totalnum];
System.out.println("enter number");
for(int i=0;i<totalnum;i++){
num[i]=sc.nextInt();
	}
}
public void positive(){
System.out.println("positive num are:");
for(int i=0;i<totalnum;i++){
if(num[i]>=0){

System.out.println(num[i]);
}
}
}
public void nagetive(){
System.out.println("nagetive num are:");
for(int i=0;i<totalnum;i++){
if(num[i]<=0){
System.out.print(num[i]);
}
}

}

public void odd(){
System.out.println("odd num are:");
for(int i=0;i<totalnum;i++){
if(num[i]%2==1){
System.out.print(num[i]);
}
}

}

public void even(){
System.out.println("even num are:");
for(int i=0;i<totalnum;i++){
if(num[i]%2==0){
System.out.print(num[i]);
}
}
}
public void zeros(){
for(int i=0;i<totalnum;i++){
if(num[i]==0){
System.out.println(num[i]);
}
}

}
public static void main(String args[]){
IntegerCheck ob=new IntegerCheck();
ob.positive();
ob.nagetive();
ob.odd();
ob.even();
ob.zeros();
}
}

