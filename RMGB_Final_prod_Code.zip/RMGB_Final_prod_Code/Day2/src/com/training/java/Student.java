package com.training.java;

import java.util.Scanner;
public class Student
{
	private int stdid;
	private String stdname;
	private int score;
	Scanner sc=new Scanner(System.in);
	public void take()
	{
	System.out.println("enter student id");
	stdid=sc.nextInt();
	System.out.println("enter student Name");
	stdname=sc.next();
	System.out.println("enter student Score");
	score=sc.nextInt();
	}
	public void show(){
	System.out.println("student id:"+stdid);
	System.out.println("enter student Name"+stdname);
	System.out.println("enter student Score"+score);
	}

public static void main(String args[]){
Student ob1=new Student();
ob1.take();
ob1.show();
}

}