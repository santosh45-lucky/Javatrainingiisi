package com.training.java;

import java.util.*;
public class ArraySum{
int num[];
Scanner sc;
int totalnum;
ArraySum(){
	sc=new Scanner(System.in);
	System.out.println("Enter total number");
	totalnum=sc.nextInt();
	num=new int[totalnum];
	} 
	public void acpect(){
	for(int i=0;i<totalnum;i++){
	System.out.println("eneter the number");
	num[i]=sc.nextInt();
	}
}
	public void display(){
int sum=0;
	for(int value:num){
	
	sum=sum+value;
	}
System.out.println("sum is"+sum);
	}
public static void main(String args[]){
ArraySum ob=new ArraySum();
ob.acpect();
ob.display();
}
}
