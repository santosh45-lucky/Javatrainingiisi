package com.java.inheritance;
import java.util.*;
public class Employee {
private long empid;
private String empname;
private String empaddress;
private long empph;
protected  double basicsalary;
protected double allownce=250.80;
protected double hra=100.50;
protected Scanner sc;
public Employee() {
	sc=new Scanner(System.in);
}

public Employee(int id,String name,String address,long no) {
	this.empid=id;
	this.empname=name;
	this.empaddress=address;
	this.empph=no;
}
public void  calculatesalary() {
	System.out.println("Basic salary is "+basicsalary);
	double salary;
	salary=basicsalary+((basicsalary*allownce/100))+((basicsalary*hra/100));
	System.out.println("salary is"+salary);
}
public void transportAllownce() {
	double transportallownce;
	transportallownce=10*basicsalary/100;
	System.out.println("transportallownce"+transportallownce);
}
public void show() {
	System.out.println("id:"+this.empid);
	System.out.println("name:"+this.empname);
	System.out.println("address:"+this.empaddress);
}
}
