package com.java.inheritance;
import com.java.inheritance.Employee;
import java.util.*;
public class Menu  {
Scanner sc;
Manager memp;
Trainee temp;
Menu(){
	sc=new Scanner(System.in);
}
	public void showDetails() {
		
	int ch=0;
	String choice="y";
	while(choice.equals("y")) {
		System.out.println("enter your choice");
		System.out.println("1.show manager details");
		System.out.println("2.show trainee details");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Deatils of an manager");
			memp=new Manager(1256,"peter","india",46464,45000);
			memp.show();
			memp.calculatesalary();
			memp.transportAllownce();
			break;
		case 2:
			System.out.println("Deatils of an trainee");
			temp=new Trainee(1298,"santosh","india",97979,45000);
			temp.show();
			temp.calculatesalary();
			temp.transportAllownce();
			break;
		}
		System.out.println("do you want to contiinue");
		choice=sc.next();		
	}
	}

}
