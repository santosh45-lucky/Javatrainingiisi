package com.java.inheritance;

public class Activity{
	private static Menu ob1;
	
	public static void main(String args[]) {
		ob1=new Menu();
		ob1.showDetails();
	}

}
