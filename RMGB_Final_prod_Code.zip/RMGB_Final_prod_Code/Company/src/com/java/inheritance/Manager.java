package com.java.inheritance;

public class Manager extends Employee {

public	Manager(int id,String name,String address,long no,double salary) {
	super(id,name,address,no);
	basicsalary=salary;
}

	
public void transportAllownce() {
	double transportallownce;
	transportallownce=15*basicsalary/100;
	System.out.println("transportallownce fo an manager"+transportallownce);
}	

}




