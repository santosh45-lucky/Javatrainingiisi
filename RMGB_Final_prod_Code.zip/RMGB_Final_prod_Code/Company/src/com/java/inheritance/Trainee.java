package com.java.inheritance;

public class Trainee extends Employee {
public	Trainee(int id,String name,String address,long no,double salary) {
	super(id,name,address,no);
	basicsalary=salary;
}
public void  calculatesalary() {
	double salary;
	salary=basicsalary+((basicsalary*allownce/100))+((basicsalary*hra/100));
	System.out.println("salary is"+salary);
}

}
