package com.bms.pojo;

public class BankAccount {
	private String name;
	private String address;
	private String acctype;
	private double balance;
	private int notransaction;
	private String accno;
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAcctype() {
		return acctype;
	}
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getNotransaction() {
		return notransaction;
	}
	public void setNotransaction(int notransaction) {
		this.notransaction = notransaction;
	}

}
