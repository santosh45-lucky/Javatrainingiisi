package com.bms.menu;
import java.util.*;
import com.bms.BankService.*;
public class Menu {
Scanner sc;
BankService bankservice;	
public Menu() {

bankservice=new BankService();
}
public void showDeatils() {
	sc=new Scanner(System.in);
	int ch=0;
	String choice="y";
	while(choice.equals("y")){
	System.out.println("enter your choice");
	System.out.println("1.Insert Acc Details");
	System.out.println("2.view deatils");
	System.out.println("3.deposite amount");
	System.out.println("4.withdraw");
	System.out.println("5.chngae address");
	System.out.println("6.exit");
	ch=sc.nextInt();
	switch(ch) {
	case 1:
		bankservice.insertDeatils();
		break;
	case 2:
		bankservice.showDetails();
		break;
		
	case 3:
		bankservice.depositeamount();
		break;
		
	case 4:
		bankservice.withdrawmoney();
		break;

	case 5:
		bankservice.changeaddress();
		break;
	case 6:
		System.exit(0);
	}
	System.out.print("Do you want to continue");
	choice=sc.next();
}
	}
}
