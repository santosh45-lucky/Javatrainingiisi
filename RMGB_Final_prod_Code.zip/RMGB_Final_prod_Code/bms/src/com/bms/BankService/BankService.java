package com.bms.BankService;
import com.bms.dao.*;

public class BankService {
public BankAccountDao bankdao;
public BankService() {
	bankdao=new BankAccountDao();
}
public void insertDeatils() {
	bankdao.Insert();
}
public void showDetails() {
	bankdao.disp();
}
public void depositeamount() {
	bankdao.deposite();
}
public void withdrawmoney() {
	bankdao.withdraw();
}
public void changeaddress() {
	bankdao.change();
}
}
