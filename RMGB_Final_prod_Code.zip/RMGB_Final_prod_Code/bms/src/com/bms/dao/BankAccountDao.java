package com.bms.dao;
import java.util.*;
import com.bms.pojo.*;
public class BankAccountDao {
private BankAccount arr[];
private long accno=1000;
Scanner sc;

public BankAccountDao() {
	sc=new Scanner(System.in);
}
public void Insert() {
	System.out.println("Enter no of Account wants to open");
	int nacc=sc.nextInt();
	arr=new BankAccount[nacc];
	for(int i=0;i<arr.length;i++) {
		arr[i]=new BankAccount();
		arr[i].setAccno("BA"+Long.toString(accno));
		accno++;
		System.out.println("Enter Name: ");
		arr[i].setName(sc.next());
		System.out.println("enter your address: ");
		arr[i].setAddress(sc.next());
		System.out.println("enter AccType");
		arr[i].setAcctype(sc.next());
		System.out.println("enter your Balance");
		arr[i].setBalance(sc.nextDouble());
		//System.out.println("enter your no of ttransaction");
		//arr[i].setNotransaction(sc.nextInt());
		
	}
}
public void disp() {
	for(BankAccount b:arr){ 
	System.out.println("Accno: "+b.getAccno());	
	System.out.println("name: "+b.getName());
	System.out.println("address: "+b.getAddress());
	System.out.println("Acctype: "+b.getAcctype());
	System.out.println("Balance: "+b.getBalance());
	System.out.println("no of transaction: "+b.getNotransaction());
	}
}
public void deposite() {
	System.out.println("enter accno which you want to deposite");
	String ac=sc.next();
	
	
	for(int i=0;i<arr.length;i++) {
		if(arr[i].getAccno()==ac) {
			System.out.println("how much amount you want to addd");
			double addamount=sc.nextDouble();
			//addamount=addamount+arr[i].getBalance();
			//arr[i].getBalance()=addamount;//why its showing error;
			//arr[i].setBalance(addamount);
			arr[i].setBalance(arr[i].getBalance()+addamount);
			arr[i].setNotransaction(arr[i].getNotransaction()+1);
			
		}
	}
	

		
	}
public void withdraw() {
	System.out.println("Enter your acc form which you want to withdraw");
	String ac=sc.next();

	
	for(int i=0;i<arr.length;i++) {
		System.out.println("enter amount");
		double amount=sc.nextDouble();
		if(arr[i].getAccno()==ac) {
			arr[i].setBalance(arr[i].getBalance()-amount);
			arr[i].setNotransaction(arr[i].getNotransaction()+1);
		}else {
			System.out.println("enter correct acc no");
		}
	}

	}
public void change() {
	System.out.println("Enter your acc form which you want to Chnage address");
	String ac=sc.next();
	System.out.println("enter current address");
	String address=sc.next();
	for(int i=0;i<arr.length;i++) {
		if(arr[i].getAccno()==ac) {
			arr[i].setAddress(address);	
}
	}
}
public void notransation() {
	
}


}
