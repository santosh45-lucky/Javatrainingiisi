package com.bms.client;
import com.bms.menu.*;
public class Client {
public static void main(String args[]) {
	Menu ob=new Menu();
	ob.showDeatils();
}
}
