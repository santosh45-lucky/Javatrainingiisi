package com.java.training;

public class Main {
private int empid;
private String empname;
private static int salary;

public void disply() {
	System.out.println(empid);
	System.out.println(empname);
	System.out.println(salary);
}
public static void main(String args[]) {
Main ob1=new Main();
ob1.empid=1;
ob1.empname="santosh";
ob1.salary=20000;
ob1.disply();
Main ob2=new Main();
ob2.disply();//when you call the dispaly method for object 2 it wil accpect tthe value of salary
ob2.salary=23000;
ob2.disply();
}

}
