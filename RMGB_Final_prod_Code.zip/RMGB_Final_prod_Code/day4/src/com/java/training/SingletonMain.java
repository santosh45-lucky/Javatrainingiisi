package com.java.training;

public class SingletonMain {
public static void main(String args[]) {
	for(int i=0;i<100;i++) {
	SinngleTon ob1=SinngleTon.getobj();
	ob1.disp();
	SinngleTon ob2=SinngleTon.getobj();
	ob2.disp();
	}
}
}
