package com.java.training;

public class SinngleTon {
	private static SinngleTon d1;
	private SinngleTon() {
		
	}
	public static SinngleTon getobj() {
		d1=new SinngleTon();
		return d1;
		
	}
	public void disp() {
		System.out.println("wewlcome to singleton class");
	}

}
