package com.java.inheritance;
import java.util.*;
public class Employee {
private int id;
private String name;
private double salary;
protected Scanner sc;
public Employee(){
	sc=new Scanner(System.in);
}
public void accpect() {
	System.out.println("enter emp id");
	id=sc.nextInt();
	System.out.println("enter emp name");
	name=sc.next();
	
}
public void disp() {
	System.out.println(" emp id"+id);
	System.out.println("emp name"+name);
}
}
