package com.java.inheritance;

public class Base {
private int id;
protected String name;
Base(){
	System.out.println("base class constructor");
}
}
