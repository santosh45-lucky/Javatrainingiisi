package com.java.inheritance;

public class Parentemp extends Employee {
private double salary;
private String dob;

public void accpect() {
	super.accpect();

	System.out.println("enter emp dob");
	dob=sc.next();
	System.out.println("enter emp salary");
	salary=sc.nextDouble();
}
public void disp() {
	super.disp();
	System.out.println(" emp dob"+dob);
	System.out.println("emp salary"+salary);
}
public static void main(String args[]) {
	System.out.println("callling employee details");
	Employee emp1=new Employee();
	emp1.accpect();
	emp1.disp();
	Parentemp pemp=new Parentemp();

	pemp.accpect();
	pemp.disp();
	
}
}
