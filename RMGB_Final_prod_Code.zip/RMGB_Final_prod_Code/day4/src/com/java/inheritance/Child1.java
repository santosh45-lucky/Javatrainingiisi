package com.java.inheritance;

public class Child1 extends Parent1{
public void show() {
	System.out.println("meethod of child is called");
}
public static void main(String args[]) {
	Parent1 ob1=new Parent1();
	ob1.disp();
	Child1 ob2=new Child1();
	ob2.show();
	Parent1 ob3=new Child1();
	ob3.disp();
}
}
