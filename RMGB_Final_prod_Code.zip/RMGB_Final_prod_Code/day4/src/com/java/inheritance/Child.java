package com.java.inheritance;

public class Child extends Base {
	
Child(){
	System.out.println("child class constructor");
}
public static void main(String args[]) {
	
Child ob=new Child();
}
	
}
