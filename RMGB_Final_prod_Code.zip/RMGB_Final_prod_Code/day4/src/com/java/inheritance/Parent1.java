package com.java.inheritance;

public class Parent1 {
public void disp() {
	System.out.println("parent class method is called");
}
}
