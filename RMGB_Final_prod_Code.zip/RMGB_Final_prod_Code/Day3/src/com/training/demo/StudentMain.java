package com.training.demo;

public class StudentMain {
	private Student str[];
	public StudentMain() {
		str=new Student[2];
	}
	public void accpet() {
		str[0]=new Student();
		str[0].setStudentid(1);
		str[0].setName("santosh");
		str[0].setScore(89);
		str[1]=new Student();
		str[1].setStudentid(2);
		str[1].setName("lucky");
		str[1].setScore(99);
		
	}
	public void show()
	{
		for(Student s:str) {
			System.out.println(s.getName());
			System.out.println(s.getStudentid());
			System.out.println(s.getScore());
		}
	}
	public static void main(String args[]) {
		StudentMain ob=new StudentMain();
		ob.accpet();
		ob.show();
	}
}
