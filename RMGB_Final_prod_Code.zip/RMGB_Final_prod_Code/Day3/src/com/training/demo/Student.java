package com.training.demo;

public class Student {
private  int studentid;
private int score;
private String name;
public  void setStudentid(int studentid) {
	this.studentid=studentid;
	
}
public int getStudentid() {
	return studentid;
}
public  void setName(String name) {
	this.name=name;
	
}
public String getName() {
	return name;
}
public  void setScore(int score) {
	this.score=score;
	
}
public int getScore() {
	return score;
}
}
