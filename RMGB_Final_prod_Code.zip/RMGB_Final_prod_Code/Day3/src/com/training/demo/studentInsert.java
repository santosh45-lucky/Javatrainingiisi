package com.training.demo;
import java.util.*;
public class studentInsert {
private Scanner sc;
private Student str[];
int nid;
public studentInsert() {
	sc=new Scanner(System.in);
	System.out.println("enter no of student");
	int n=sc.nextInt();
	str=new Student[n];
	
	
}
public void acc() {
	for(int i=0;i<str.length;i++) {
		str[i]=new Student();
		System.out.println("enteer student id");
		str[i].setStudentid(sc.nextInt());
	//	str[i]=new Student();
		System.out.println("enteer student name");
		str[i].setName(sc.next());
		//str[i]=new Student();
		System.out.println("enteer student score");
		str[i].setScore(sc.nextInt());
}
	}
public void show() {
	for(Student s:str) {
		System.out.println("student id: "+s.getStudentid());
		System.out.println("student name"+s.getName());
		System.out.println("student score"+s.getScore());
	}
	
}

public void search() {
	System.out.println("eneter id what you want tocehck");
	nid=sc.nextInt();
	Student sfound=null;
	for(Student s:str) {
		if(s.getStudentid()==nid) {
			sfound=s;
		}
	}
	if(sfound!=null) {
		System.out.println("student found");
	}
	else {
		System.out.println("Student not foundd");
	}
}
public void change() {
	System.out.println("enetr id to whome you want to change the score");
	nid=sc.nextInt();
	for(Student s:str) {
		if(s.getStudentid()==nid) {
			s.setScore(89);
		}
	}
	
}
public void Disp() {
	for(Student s:str) {
	System.out.println("student score"+s.getScore());
}
}
public static void main(String args[]) {
	studentInsert ob=new studentInsert();
	ob.acc();
	ob.change();

	ob.Disp();
	
}
}

