package com.demo.client;
import com.demo.menu.*;
public class AppMain {
public static void main(String args[]) {
	Menu ob=new Menu();
	ob.displayMenu();
}
}
