package com.demo.dao;
import com.demo.pojo.*;
import java.util.*;

public class employeDao {
private  employee emparr[];
Scanner  sc;
public employeDao() {
	sc=new Scanner(System.in);
}
public void insert() {
	System.out.println("Enter no of employe");
	int nemp=sc.nextInt();
	emparr=new employee[nemp];
	for(int i=0;i<emparr.length;i++) {
		emparr[i]=new employee();
		System.out.println("enter employee id");
		emparr[i].setEmpid(sc.nextInt());
		System.out.println("enter employee name");
		emparr[i].setName(sc.next());
		System.out.println("enter employee salary");
		emparr[i].setSalary(sc.nextInt());
	}
}
public void display() { 
	for(employee e:emparr) {
		if(e!=null) {
		System.out.println("emp id"+e.getEmpid());
		System.out.println("emp name"+e.getName());
		System.out.println("emp salary"+e.getSalary());
	}
	}
}
public void delete() {
	System.out.println("eneter employee id which you want to delete");
	int empid=sc.nextInt();
	employee edelete=null;
	int val=0;
	for(int i=0;i<emparr.length;i++) {
		if(emparr[i].getEmpid()==empid) {
			emparr[i]=null;
		}
	}
}
	public void update() {
		System.out.println("eneter employee id which you want to update");
		int empid=sc.nextInt();
		for(employee e:emparr) {
			
			
		}
	
}
}
