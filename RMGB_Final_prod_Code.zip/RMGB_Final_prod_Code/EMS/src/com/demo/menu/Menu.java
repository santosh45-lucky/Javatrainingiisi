package com.demo.menu;
import com.demo.service.*;
import java.util.*;

public class Menu {
	Scanner sc;
EmpService empservice;
public Menu() {
	empservice=new EmpService();
}
public void displayMenu() {
	sc=new Scanner(System.in);
	String choice="y";
	int ch=0;
	while(choice.equals("y")) {
		System.out.println("entter you chhoice");
		System.out.println("1.Insert employee");
		System.out.println("2.delete employee");
		System.out.println("3.update employee");
		System.out.println("4.view deatils");
		System.out.println("5.exit");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			empservice.insertDetails();
			break;
		case 2:
			empservice.deleteE();
			break;
			
		case 3:
			empservice.updateE();
			break;
		case 4:
			empservice.show();
			break;
		case 5:
		System.exit(0);
		}
		System.out.println("Do youwant to continue");
		choice=sc.next();
	}
}
}
