package com.demo.service;
import com.demo.dao.*;
public class EmpService {
private employeDao empdao;
public EmpService() {
	empdao=new employeDao();
	}
	public void insertDetails() {
	empdao.insert();	
	}
	public void show() {
		empdao.display();
	}
	public void deleteE() {
		empdao.delete();
	}
	public void updateE() {
		empdao.update();
	}
	
}

