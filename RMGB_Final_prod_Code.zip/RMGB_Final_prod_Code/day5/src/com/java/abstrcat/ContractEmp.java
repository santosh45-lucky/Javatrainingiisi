package com.java.abstrcat;

public class ContractEmp extends Employee{
	private double conamount;
	private int conperiod;
	
public void accept() {
	super.accept();
	System.out.println("enter contract amount");
	conamount=sc.nextDouble();

	System.out.println("enter contract period");
	conperiod=sc.nextInt();
}
public void display() {
	super.display();

	System.out.println(" contract amount is:"+conamount);
	
	System.out.println("contract period is"+conperiod);
	
}

public void calsalary() {
	double salary=conamount*conperiod;
	System.out.println("annual salary is"+salary);
}
}
