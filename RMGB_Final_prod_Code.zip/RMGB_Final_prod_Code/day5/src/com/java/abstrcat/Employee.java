package com.java.abstrcat;
import java.util.*;
public abstract class Employee {
	Scanner sc;
	private double empid;
	private String empname;
Employee(){
	sc=new Scanner(System.in);
}
public void accept() {
	System.out.println("enter id");
	empid=sc.nextDouble();
	System.out.println("enter name");
	empname=sc.next();
}
public void display() {
	System.out.println("Emp id:"+empid);
	System.out.println("emp name:"+empname);
}
public abstract void calsalary();

}
