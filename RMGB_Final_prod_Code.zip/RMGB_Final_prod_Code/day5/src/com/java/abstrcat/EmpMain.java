package com.java.abstrcat;
import java.util.*;
public class EmpMain {


	
public static void main(String args[]) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter your choice");
	System.out.println("1.Parmanet Employee");
	System.out.println("2.contract Employee");
	int ch=sc.nextInt();
	Employee eobj;	
	switch(ch) {
	case 1:
		eobj=new parmanentEmp();
		eobj.accept();
		eobj.display();
		eobj.calsalary();
		break;
	case 2:
		eobj=new ContractEmp();
		eobj.accept();
		eobj.display();
		eobj.calsalary();
		break;
	}

}
}
