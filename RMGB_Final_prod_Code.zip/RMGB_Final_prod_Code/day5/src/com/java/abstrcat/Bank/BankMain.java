package com.java.abstrcat.Bank;

public class BankMain {
public static void main(String args[]) {
	Bank ob1=new BankA();
	System.out.println("balance of bankA"+ob1.getBalance());
	Bank ob2=new BankB();
	System.out.println("balance of bankb"+ob2.getBalance());
	Bank ob3=new BankC();
	System.out.println("balance of bankc"+ob3.getBalance());
}
}
