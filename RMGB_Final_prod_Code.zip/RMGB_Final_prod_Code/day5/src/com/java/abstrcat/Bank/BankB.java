package com.java.abstrcat.Bank;

public class BankB extends Bank{
public double getBalance() {
	return 200;
}
}
