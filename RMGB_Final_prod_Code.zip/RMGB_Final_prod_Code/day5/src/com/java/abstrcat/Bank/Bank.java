package com.java.abstrcat.Bank;

public abstract class Bank {
public abstract double getBalance();
}
