package com.java.abstrcat.Bank;

public class BankA  extends Bank{
	public double getBalance() {
		return 100;
	}

}
