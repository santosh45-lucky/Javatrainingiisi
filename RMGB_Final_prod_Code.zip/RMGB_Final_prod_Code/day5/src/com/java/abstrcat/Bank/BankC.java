package com.java.abstrcat.Bank;

public class BankC extends  Bank {
public double getBalance() {
	return 300;
}
}
