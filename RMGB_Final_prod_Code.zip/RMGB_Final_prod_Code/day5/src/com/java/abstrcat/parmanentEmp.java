package com.java.abstrcat;

public class parmanentEmp extends Employee{
private double salary;
//@override
	public void accept() {
	super.accept();
		System.out.println("enter salary");
		salary=sc.nextDouble();
	}
public void display() {
	super.display();
	System.out.println("salary is: "+salary);
}
	public void calsalary() {
		salary=salary*12;
		System.out.println("annual salary"+salary);
		
	}

}
