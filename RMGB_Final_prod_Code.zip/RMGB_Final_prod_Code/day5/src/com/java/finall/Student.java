package com.java.finall;

public class Student {
public final int id=10;
}
