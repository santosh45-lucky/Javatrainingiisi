package com.java.interfacce.handson;

import java.util.Scanner;

public class AdultUser implements LibraryUser {
	private int age;
	protected String bookType;
		
		AdultUser(){
			Scanner sc=new Scanner(System.in);
			System.out.println("enter adults Details");
			System.out.println("enter age:");
			age=sc.nextInt();
			System.out.println("enter booktype:");
			bookType=sc.next();
		}
	@Override
	public void registerAccount() {
		// TODO Auto-generated method stub
		if(age>12) {
			System.out.println("your sucessfully register");
		}else {
			System.out.println("sorry your age should greater than 12");
		}

	}

	@Override
	public void requestBook() {
		// TODO Auto-generated method stub
		if(bookType.equals("fiction")) {
			System.out.println("book issued suceessfully");
		}else {
			System.out.println("oppps you are allowed to take only adult books");
		}
	}

}
