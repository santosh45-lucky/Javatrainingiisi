package com.java.interfacce.handson;
import java.util.*;
public class KidUsers implements LibraryUser{
private int age;
protected String bookType;
	
	KidUsers(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter kids Details");
		System.out.println("enter age:");
		age=sc.nextInt();
		registerAccount();
		System.out.println("enter booktype:");
		bookType=sc.next();
	}
	public void registerAccount() {
		// TODO Auto-generated method stub
		if(age>12) {
			System.out.println("sorry age muste be less than 12");
		}else {
			System.out.println("Your suceessfully register");
		}
	}

	@Override
	public void requestBook() {
		// TODO Auto-generated method stub
		if(bookType.equals("kids")) {
			System.out.println("book issued suceessfully");
		}else {
			System.out.println("oppps you are allowed to take only kids books");
		}
		
	}

}
