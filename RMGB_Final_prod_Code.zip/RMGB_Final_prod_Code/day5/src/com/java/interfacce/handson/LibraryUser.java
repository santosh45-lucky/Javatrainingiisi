package com.java.interfacce.handson;

public interface LibraryUser {
void registerAccount();
void requestBook();

}
