package com.java.interfacce.handson;

public class LibrarayDemo {
public static void main(String args[]) {
	KidUsers k=new KidUsers();
	//k.registerAccount();
	k.requestBook();
	AdultUser a=new AdultUser();
	a.registerAccount();
	a.requestBook();
}
}
