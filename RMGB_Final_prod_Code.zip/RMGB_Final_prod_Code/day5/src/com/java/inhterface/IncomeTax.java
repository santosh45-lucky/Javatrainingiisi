package com.java.inhterface;

public interface IncomeTax {
void accpetDeatilsIncom();
	
}
