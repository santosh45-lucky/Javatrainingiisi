package com.java.inhterface;

public interface PersonalDetails {
void acceptName();
void acceptAddress();
int x=30;

}
