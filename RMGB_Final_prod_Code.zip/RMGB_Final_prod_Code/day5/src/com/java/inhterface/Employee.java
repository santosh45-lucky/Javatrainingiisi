package com.java.inhterface;

public class Employee implements PersonalDetails,IncomeTax{

@Override
public void acceptName() {
	// TODO Auto-generated method stub
System.out.println("accepeting mname deatils of an employee");	
}

@Override
public void acceptAddress() {
	// TODO Auto-generated method stub
	System.out.println("accepeting address deatils of an employe");	
}


@Override
public void accpetDeatilsIncom() {
	// TODO Auto-generated method stub
	System.out.println("accpeting income tax deatils");	
}
}
