package com.java.inhterface;

public class Vendor implements PersonalDetails{

	@Override
	public void acceptName() {
		// TODO Auto-generated method stub
		System.out.println("accepeting name deatils of vendor");	
	}

	@Override
	public void acceptAddress() {
		// TODO Auto-generated method stub
		System.out.println("accepeting address deatils of vendor");			
	}

}
