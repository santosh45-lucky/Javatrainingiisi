package com.java.inhterface;

public class AppMain {
	public static void main(String args[]) {
    Employee ob=new Employee();	
	ob.acceptAddress();
	ob.acceptName();
	ob.accpetDeatilsIncom();
	PersonalDetails ob1=new Vendor();
	}
}
