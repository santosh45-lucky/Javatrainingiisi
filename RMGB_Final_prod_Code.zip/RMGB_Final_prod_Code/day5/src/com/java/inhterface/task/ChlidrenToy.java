package com.java.inhterface.task;

public interface ChlidrenToy {
void demo();
}
