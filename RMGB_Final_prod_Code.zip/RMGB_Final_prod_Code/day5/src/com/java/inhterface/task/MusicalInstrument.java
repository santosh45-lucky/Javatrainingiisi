package com.java.inhterface.task;

public interface MusicalInstrument {
String playmsg="play music";
boolean isBroke();
void repair();
void demo();
void instrumentname();
void playMSg();
void play(String s);
}
