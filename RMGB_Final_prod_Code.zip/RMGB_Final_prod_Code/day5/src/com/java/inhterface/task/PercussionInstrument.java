package com.java.inhterface.task;

public interface PercussionInstrument extends ChlidrenToy,MusicalInstrument{
//void demo();
void hit();
void shake();
}
