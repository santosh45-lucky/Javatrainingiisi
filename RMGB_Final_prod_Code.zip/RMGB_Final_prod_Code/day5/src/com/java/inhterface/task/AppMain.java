package com.java.inhterface.task;

public class AppMain implements PercussionInstrument,BrassInstrument,StringInstrument {

	@Override
	public boolean isBroke() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void repair() {
		// TODO Auto-generated method stub
		System.out.println("Repair method is called");
	}

	@Override
	public void demo() {
		// TODO Auto-generated method stub
		System.out.println("demo method is called");
	}

	@Override
	public void instrumentname() {
		// TODO Auto-generated method stub
		System.out.println("instrumentname is called");
	}

	@Override
	public void playMSg() {
		// TODO Auto-generated method stub
		System.out.println("play....");
	}

	@Override
	public void play(String s) {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

	@Override
	public void bow(String bb) {
		// TODO Auto-generated method stub
		System.out.println(bb);
	}

	@Override
	public void pluck(String pp) {
		// TODO Auto-generated method stub
		System.out.println(pp);
	}

	@Override
	public void buzz(String a) {
		// TODO Auto-generated method stub
		System.out.println(a);
	}

	@Override
	public void hit() {
		// TODO Auto-generated method stub
		System.out.println("hit....");
	}

	@Override
	public void shake() {
		// TODO Auto-generated method stub
		System.out.println("shake is called");
	}
	

}
