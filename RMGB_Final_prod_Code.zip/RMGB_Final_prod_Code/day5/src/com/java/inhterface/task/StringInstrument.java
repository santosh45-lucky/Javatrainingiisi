package com.java.inhterface.task;

public interface StringInstrument extends MusicalInstrument {
void bow(String b);
void pluck(String p);
}
