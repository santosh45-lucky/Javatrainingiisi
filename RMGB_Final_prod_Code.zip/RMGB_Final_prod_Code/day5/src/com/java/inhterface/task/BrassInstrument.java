package com.java.inhterface.task;

public interface BrassInstrument extends MusicalInstrument{
void buzz(String a);
}
