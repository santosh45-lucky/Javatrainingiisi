package com.java.inhterface.task;

public class Main {
public static void main(String args[]) {
	AppMain ob=new AppMain();
	ob.bow("hi bow");
	ob.buzz("buzz");
	ob.demo();
	ob.hit();
	ob.instrumentname();
	ob.isBroke();
	ob.play("music");
	ob.playMSg();
	ob.pluck("pluckkkkkk");
	
}
}
