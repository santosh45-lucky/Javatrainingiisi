package com.java.training.abstaract;

public class Main {
public static void main(String args[]) {
	Parent sub1=new Sub1();
	sub1.message();
	Parent sub2=new Sub2();
	sub2.message();
}
}
