package com.java.training.abstaract;

public class Sub1 extends Parent{
	public void message() {
		System.out.println("this is 1st subclass");
	}

}
