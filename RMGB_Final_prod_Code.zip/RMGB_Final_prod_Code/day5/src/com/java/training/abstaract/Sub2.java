package com.java.training.abstaract;

public class Sub2 extends Parent {
public void message() {
	System.out.println("this is 2nd subclass");
}
}
