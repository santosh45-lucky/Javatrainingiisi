package com.java.training.abstaract;

public abstract class Parent {
public abstract void message();
}
