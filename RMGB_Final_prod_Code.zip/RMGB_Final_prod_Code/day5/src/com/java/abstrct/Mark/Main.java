package com.java.abstrct.Mark;

public class Main {
public static void main(String args[]) {
	System.out.println("enter studentA details");
	Marks st1=new StudentA(50,50,50);
	st1.getPercentage();
	System.out.println("enter studentB details");
	Marks st2=new StudentB(50,50,50,50);
	st2.getPercentage();
}
}
