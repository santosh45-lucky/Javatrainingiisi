package com.java.abstrct.Mark;

import java.util.Scanner;

public class StudentB extends Marks{
	protected int sub4;
	StudentB(int s1,int s2,int s3,int s4){
		/*Scanner sc=new Scanner(System.in);
		System.out.println("enter sub1 mark");
		sub1=sc.nextInt();
		System.out.println("enter sub2 mark");
		sub2=sc.nextInt();
		System.out.println("enter sub3 mark");
		sub3=sc.nextInt();
		System.out.println("enter sub4 mark");
		sub4=sc.nextInt();*/
		super.sub1=s1;
		super.sub2=s2;
		super.sub3=s3;
		sub4=s4;
	}
	public void getPercentage() {
		double per=(sub1+sub2+sub3+sub4)/4;
		System.out.println("percentage of sudentB is:"+per);
	}
}
