package com.java.abstrct.Mark;

public abstract class Marks {
protected int sub1;
protected int sub2;
protected int sub3;
public abstract void getPercentage();
}
