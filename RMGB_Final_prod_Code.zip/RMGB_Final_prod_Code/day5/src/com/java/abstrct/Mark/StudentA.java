package com.java.abstrct.Mark;
import java.util.*;
public class StudentA extends Marks {
StudentA(int s1,int s2,int s3){
	/*Scanner sc=new Scanner(System.in);
	System.out.println("enter sub1");
	sub1=sc.nextInt();
	System.out.println("enter sub2");
	sub2=sc.nextInt();
	System.out.println("enter sub3");
	sub3=sc.nextInt();*/
	super.sub1=s1;
	super.sub2=s2;
	super.sub3=s3;
}
public void getPercentage() {
	double per=(sub1+sub2+sub3)/3;
	System.out.println("percentage of sudentA is:"+per);
}
}
