package com.handson.exception;

public class TaxNotEligbleException extends Exception{
	public String getMessage() {
		return "not eligble";
	}
}
