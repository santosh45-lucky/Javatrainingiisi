package com.handson.exception;

public class EmployeeNameInvalid extends Exception{
public String getMessage(){
return "invalid employee name";	
}
	
}

