package com.handson.exception;
import java.util.*;

import com.java.exceotions.InvalidAmountException;
import com.java.exceotions.InvalidUser;
import com.java.exceotions.Main;
public class TaxCalculator {
Scanner sc;
String empname;
boolean isindian=true;
double salary;
double tax;
public void checkcountry() throws CountryNotValid{
	sc=new Scanner(System.in);
	System.out.println("Are you an indian");
	boolean country=sc.hasNext();
	if(!isindian) {
	throw new CountryNotValid();
}else {
	System.out.println("Valid Country");
}
}
public void checkname() throws EmployeeNameInvalid{
	sc=new Scanner(System.in);
	System.out.println("enter employee name");
	empname=sc.next();
	if(empname.equals(null)) {
	throw new EmployeeNameInvalid();
}else {
	System.out.println("Valid user");
}
}
public void Taxeligble() throws TaxNotEligbleException{
	sc=new Scanner(System.in);
	System.out.println("enter salary");
	salary=sc.nextDouble();
	System.out.println("are you indian");
	boolean country=sc.hasNext();
	if((salary>=10000) && !isindian) {
		{
			tax=salary*8/10;
			System.out.println("tax is:"+tax);
		}
}else {
	throw new TaxNotEligbleException();
}
}
public static void main(String agrgs[]) {
	TaxCalculator ob=new TaxCalculator();
	try {
		ob.checkcountry();
	}catch(CountryNotValid e) {
		System.out.println(e.getMessage());
	}
	try {
		ob.checkname();;
	}catch(EmployeeNameInvalid e) {
		System.out.println(e.getMessage());
	}
	try {
		ob.Taxeligble();
	}catch(TaxNotEligbleException e) {
		System.out.println(e.getMessage());
	}
}
}
