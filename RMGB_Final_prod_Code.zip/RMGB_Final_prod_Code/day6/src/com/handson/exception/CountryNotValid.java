package com.handson.exception;

public class CountryNotValid extends Exception{
public String getMessage() {
	return "invalid Country";
}
}
