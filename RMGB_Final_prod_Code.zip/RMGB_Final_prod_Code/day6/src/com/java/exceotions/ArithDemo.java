package com.java.exceotions;
import java.util.*;
public class ArithDemo {
int num1;
int num2;
Scanner sc;
ArithDemo(){
	sc=new Scanner(System.in);
	
}
public void accept() {
	System.out.println("enter numbe1");
	num1=sc.nextInt();
	System.out.println("enter numbe2");
	num2=sc.nextInt();
}
public void disp() {
	
	try {
	float div=num1/num2;
	System.out.println("division is:"+div);
	}
	catch(Exception e) {
		System.out.println("your are trying to divide by zero");
	}
	
	
}
public static void main(String args[]) {
	ArithDemo ob=new ArithDemo();
	ob.accept();
	ob.disp();
}
}
