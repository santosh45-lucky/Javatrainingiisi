package com.java.exceotions;

public class InvalidAmountException extends Exception {
public String getMessage() {
	return "invalid amoount";
}
}
