package com.java.exceotions;
import java.util.*;
public class ArrayStoreException {
/*int num[];
Scanner sc;
public void  store() {
	sc=new Scanner(System.in);
	num=new int[5];
	
		try {
		for(int i=0;i<num.length;i++) {
		System.out.println("enter numer");
		num[i]=sc.nextInt();
		}
		}catch(Exception e) {
			System.out.println("please enter correct format");
		}
		}

public void disp() {
	for(int val:num) {
		System.out.println(val);
	}
}
*/
public static  void main(String args[]) {
	//ArrayStoreException ob=new ArrayStoreException();
	//ob.store();
	//ob.disp();
	try {
	Number arr[]=new Integer[6];
	arr[0]=new Double(6.6);
}catch(Exception e) {
	
}
}
}
