package com.java.exceotions;
import java.util.*;
public class NumberFormat {
	int num;
Scanner sc=new Scanner(System.in);
public void convert() {
	try {
	System.out.println("enter a valid number");
	num=sc.nextInt();
	System.out.println("entter num:"+num);
	}catch(Exception e) {
		System.out.println("enter valid type number");
	}
}
public static void main(String args[]) {
	NumberFormat ob=new NumberFormat();
	ob.convert();
}
}
