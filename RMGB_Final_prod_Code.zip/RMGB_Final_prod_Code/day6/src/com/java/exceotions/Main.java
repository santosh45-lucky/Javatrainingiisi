package com.java.exceotions;
import java.util.*;
public class Main {
double mainbalance=2000;
String user="user";
String pass="password";
Scanner sc;
double balance;
public void amoount() throws InvalidAmountException{
	sc=new Scanner(System.in);
	System.out.println("enter amount");
	balance=sc.nextDouble();
	if(balance>mainbalance) {
	throw new InvalidAmountException();
}else {
	System.out.println("transfer sucessfully");
}
}
public void userinput() throws InvalidUser{
	System.out.println("enter user name");
	String username=sc.next();
	System.out.println("entter passsword");
	String password=sc.next();
	if(!user.equals(username)&&pass.equals(password)) {
	throw new InvalidUser();
}else {
	System.out.println("login sucessfully");
}
}
public static void main(String agrgs[]) {
	Main ob=new Main();
	try {
		ob.amoount();
	}catch(InvalidAmountException e) {
		System.out.println(e.getMessage());
	}
	try {
		ob.userinput();
	}catch(InvalidUser e) {
		System.out.println(e.getMessage());
	}
}
} 
