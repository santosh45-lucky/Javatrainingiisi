package com.java.exceotions;
import java.util.*;
public class Multiplecatch {
Scanner sc;
int arr[];
String s;
public Multiplecatch() {
	sc=new Scanner(System.in);
	
}
public void accept() {
	System.out.println("enter a string");
	s=sc.next();
	System.out.println("enter arr length");
	int no=sc.nextInt();
	arr=new int[no];
	for(int i=0;i<no;i++) {
		System.out.println("enter number");
		arr[i]=sc.nextInt();
		}
}
public void disp() {
	try {
	System.out.println("enter index no for 1st value");
	int num1=sc.nextInt();
	System.out.print("enter index no for 2nd value");
	int num2=sc.nextInt();
	float div=arr[num1]/arr[num2];
	System.out.println("division is:"+div);
	Integer.parseInt(s);
	}
	
	catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("enter coorrect  index no");
	}
	catch(ArithmeticException e){
		System.out.println("tring to divide by zero");
	}
	catch(NumberFormatException e) {
	System.out.println("incorrect format");	
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}

}

public static void main(String args[]) {
	Multiplecatch ob=new Multiplecatch();
	ob.accept();
	ob.disp();
		
	}
}

