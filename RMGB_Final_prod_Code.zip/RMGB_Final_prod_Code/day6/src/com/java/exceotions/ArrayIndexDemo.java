package com.java.exceotions;
import java.util.*;
public class ArrayIndexDemo {
int arr[]= {1,2,3,4,5};
public void show() {
	try {
	System.out.println("aary elemets"+arr[6]);
}catch(Exception e) {
	System.out.println("your try to access beyond the limit");
}
}

public static void main(String args[]) {
	ArrayIndexDemo ob=new ArrayIndexDemo();
	ob.show();
}
}
