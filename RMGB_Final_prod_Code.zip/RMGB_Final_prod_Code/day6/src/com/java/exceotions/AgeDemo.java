package com.java.exceotions;
import java.util.*;
public class AgeDemo {
int age;
Scanner sc;

	

}
