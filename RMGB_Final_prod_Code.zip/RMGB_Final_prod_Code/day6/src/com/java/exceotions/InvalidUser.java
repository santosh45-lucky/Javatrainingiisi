package com.java.exceotions;

public class InvalidUser extends Exception {
public String getMessage() {
	return "invalid uuser login";
}
}
