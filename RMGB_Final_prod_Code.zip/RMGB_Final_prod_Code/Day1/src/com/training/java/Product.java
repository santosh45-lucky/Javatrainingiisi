package com.training.java;

import java.util.Scanner;

public class Product{
	public static void main(String ar[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int number1=sc.nextInt();
		System.out.println("enter second number");
		int number2=sc.nextInt();
		int result=number1*number2;
		System.out.println("Product is:"+result);
	}


}
