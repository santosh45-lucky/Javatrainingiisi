package com.training.java;

import java.util.Scanner;

public class Student{
	public static void main(String ar[])
	{
		Scanner sc=new Scanner(System.in);
		int studentid;
		String name;
		int age;
		System.out.println("Enter your id");
		studentid=sc.nextInt();
		System.out.println("enter your name");
		name=sc.next();
		System.out.println("enter your age");
		age=sc.nextInt();
		System.out.println("Student Deatils....");
		System.out.println("student id:"+studentid);
		System.out.println("student name:"+name);
		System.out.println("student age:"+age);
if(age>=18&&age<=60){
System.out.println("Your eligible");
}else{
System.out.println("Your not eligble");
}
		



	}
}
