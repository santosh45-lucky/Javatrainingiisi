package com.training.java;

import java.util.Scanner;
public class Area{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter radius");
		float radius=sc.nextFloat();
		float pi=3.14f;
		float area=pi*radius*radius;
		float perimeter=2*pi*radius;
		System.out.println("Area of an circle is:"+area);
 		System.out.println("Perimeter of an circle is:"+perimeter);


}

}