package com.training.java;

import java.util.Scanner;

public class Calculator{
	public static void main(String ar[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Two number");
		int number1=sc.nextInt();
		int number2=sc.nextInt();
		int total=number1+number2;
		System.out.println("sum is:"+total);
	}


}
