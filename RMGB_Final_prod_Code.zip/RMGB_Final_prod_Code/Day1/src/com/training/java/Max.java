package com.training.java;

	import java.util.Scanner;

	public class Max{
		public static void main(String ar[])
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter 1st number");
			int number1=sc.nextInt();
			System.out.println("Enter 2nd number");
			int number2=sc.nextInt();
			System.out.println("Enter 3rd number");
			int number3=sc.nextInt();
			/*if((number1>=number2)&&(number1>=number3)){
	System.out.println("Max is"+number1);}
		 if((number2>=number1)&&(number2>=number3)){
	System.out.println("Max is"+number2);}
	 if((number3>=number2)&&(number3>=number1)){
	System.out.println("Max is"+number2);}
			
	*/
		}
	}
