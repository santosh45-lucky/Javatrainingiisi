package com.training.java;

import java.util.*;
public class Swap{
	public static void main(String args[]){
		int number1,number2,temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 2 number");
		number1=sc.nextInt();
		number2=sc.nextInt();
		/*temp=number1;
		number1=number2;
		number2=temp;*/
			
		System.out.println("After swap 2 number is"+number1+number2);
}
}